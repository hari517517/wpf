﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace DataReaderDemo1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        public MainWindow()
        {
            InitializeComponent();
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;DataBase=Training_23Jan19_Pune;uid=sqluser;pwd=sqluser");
          
            SqlCommand cmd = new SqlCommand("select * from Student_Master",con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            con.Close();

            //dgStudent.ItemsSource = dt.DefaultView;
            dgStudent.DataContext = dt.DefaultView;
            
      
           
           
            //SqlDataReader dr = cmd.ExecuteReader();
            //while (dr.Read())
            //{
            //    MessageBox.Show(dr["Stud_Code"] + "\t" + dr["Stud_Name"] + "\t" + dr["Dept_Code"] + "\t" + dr["Stud_Dob"] + "\t" + dr["Address"]);
            //}
         
            



        }
        
    }
}

