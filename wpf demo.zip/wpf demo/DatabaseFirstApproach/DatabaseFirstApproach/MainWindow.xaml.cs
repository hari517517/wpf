﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace DatabaseFirstApproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();

        }
        public void ShowData()
        {

            TrainingEntities context = new TrainingEntities();
            dgStudent.ItemsSource = context.Student_master.ToList();


        }
        public void ClearData()
        {
            txtStudentCode.Text = "";
            txtName.Text = "";
            txtFullAddress.Text = "";
            txtDOB.Text = "";
            txtDeptCode.Text = "";


        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Student_master stud = new Student_master();
            stud.Stud_Code = Convert.ToDecimal(txtStudentCode.Text);
            stud.Stud_Name = txtName.Text;
            stud.Dept_Code = Convert.ToDecimal(txtDeptCode.Text);
            stud.Stud_Dob = Convert.ToDateTime(txtDOB.Text);
            stud.Address = txtFullAddress.Text;
            TrainingEntities context = new TrainingEntities();
            context.Student_master.Add(stud);
          int recordsAffected=  context.SaveChanges(); // to save changes in server to call savechanges on context object
            if(recordsAffected>0)
            {
                MessageBox.Show("student record added succeessfully");
                ShowData();
                ClearData();
               
            }

            else
            {
                MessageBox.Show("student record not added successfully");
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            TrainingEntities context = new TrainingEntities();
           Student_master stud = context.Student_master.Find(Convert.ToDecimal( txtStudentCode.Text));
            dgStudent.DataContext = stud;
            if(stud!=null)
            {
                dgStudent.DataContext = stud;
                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;

            }
            else
            {
                MessageBox.Show("not found");

            }
           
            


        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            TrainingEntities context = new TrainingEntities();
            Student_master stud = context.Student_master.Find(Convert.ToDecimal( txtStudentCode.Text));
           
            stud.Stud_Name = txtName.Text;
            stud.Dept_Code = Convert.ToDecimal(txtDeptCode.Text);
            stud.Stud_Dob = Convert.ToDateTime(txtDOB.Text);
            stud.Address = txtFullAddress.Text;
            int rowsAffected = context.SaveChanges();
            if(rowsAffected>0)
            {
                MessageBox.Show("UPDATED SUCCESSFULLY");
                ShowData();
                ClearData();
            }
            else
            {
                MessageBox.Show("the data is wrong");
            }


        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            TrainingEntities context = new TrainingEntities();
            Student_master stud = context.Student_master.Find(Convert.ToDecimal(txtStudentCode.Text));
            context.Student_master.Remove(stud);
            int recordsAffected = context.SaveChanges();
            if(recordsAffected>0)
            {
                MessageBox.Show("deleted successfully");
                ShowData();
            }
            else
            {
                MessageBox.Show("not deleted");
            }


        }

        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            TrainingEntities context = new TrainingEntities();
            MessageBox.Show("no of students:" +" "+ context.Student_master.Count() );

        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearData();

        }
    }
}
