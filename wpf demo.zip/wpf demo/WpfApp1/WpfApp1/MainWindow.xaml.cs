﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        String Student_Code;
        string Name;
        String Dept_Code;
        DateTime dt;
        String Address;


        private void Btnsubmit_Click(object sender, RoutedEventArgs e)
        {


            Dept_Code = txtRollNo.Text;

            Name = txtFullName.Text;
            //string gender = string.Empty;
            //if ((bool)rbMale.IsChecked)
            //{
            //    gender = rbMale.Content.ToString();

            //}
            //else if ((bool)rbFemale.IsChecked)
            //{

            //    gender = rbFemale.Content.ToString();
            //}
            Dept_Code
                = txtFullName.Text;


            txtfulladdress.SelectAll();

            string address = txtfulladdress.Selection.Text;
             dt = (DateTime)txtDOB.SelectedDate;
                
           


           
               //hq = ((ListBoxItem)lbHighQual.SelectedItem).Content.ToString();
            
            

            MessageBox.Show($"Roll-Number:  {Student_Code} \n Full-Name: {Name} \n  Full-Address: {Address} \n DateOfBirth : {dt}");
        }
    }
}
