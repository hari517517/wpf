﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CodeFirstApproachDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InstrumentContext_172404 context = new InstrumentContext_172404();

            context.Instruments.Add(new Instrument_172404() { Id = 100, Name = "Mouni", Price = 8000, Quantity = 2 });
            context.Instruments.Add(new Instrument_172404() { Id = 101, Name = "Sandeep", Price = 4000, Quantity = 3 });
            context.Instruments.Add(new Instrument_172404() { Id = 102, Name = "Minnu", Price = 6000, Quantity = 1 });





            context.SaveChanges();
            dgInstrument.ItemsSource = context.Instruments.ToList();


            var query = from ins in context.Instruments
                        where ins.Price > 5000
                        select ins;



            context.Instruments.Where(ins => ins.Price > 5000);
        }
    }
}

