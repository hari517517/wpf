﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;



namespace DisconnectedDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlDataAdapter da;
        SqlCommandBuilder cmd;
        DataSet ds = new DataSet();
        public MainWindow()
        {
            InitializeComponent();
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            da = new SqlDataAdapter("select * from Student_Master", con);
            cmd = new SqlCommandBuilder(da);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;  //primary key
            da.Fill (ds,"Stud");
            dgStudent.ItemsSource = ds.Tables["Stud"].DefaultView;

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            DataRow dr = ds.Tables["Stud"].NewRow();
            dr["Stud_Code"] = txtStudentCode.Text;
            dr["Stud_Name"] = txtName.Text;
            dr["Dept_Code"] = txtDeptCode.Text;
            dr["DOB"] = Convert.ToDateTime(txtDOB);
            dr["Address"] = txtFullAddress.Text;
            ds.Tables["Stud"].Rows.Add(dr);
            int recordsAffected = da.Update(ds, "Stud");
            if(recordsAffected>0)
            {
                MessageBox.Show("student record added succeessfully");
                Cleardata();
            }
            else
            {
                MessageBox.Show("student record not added succeessfully");
            }
                


        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            DataRow dr = ds.Tables["Stud"].Rows.Find(txtStudentCode.Text);
            if (dr != null)
            {
                txtStudentCode.Text = dr["Stud_Code"].ToString();
                txtName.Text = dr["Stud_Name"].ToString();
                txtDeptCode.Text = dr["Dept_Code"].ToString();
                txtDOB.Text = dr["Stud_Dob"].ToString();
                txtFullAddress.Text = dr["Address"].ToString();
                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;


            }
            else
            {
                MessageBox.Show("student with id" + txtStudentCode.Text + "  notfound");

            }
            //DataRow dr = ds.Tables["Stud"].Rows.Find(txtStudentCode.Text);
            //if(dr!= null)
            //{
            //    txtStudentCode.Text = dr["Stud_Code"].ToString();
            //    txtName.Text = dr["Stud_Name"].ToString();
            //    txtDeptCode.Text = dr["Dept_Code"].ToString();
            //    txtDOB.Text = dr["Stud_Dob"].ToString();
            //    txtFullAddress.Text = dr["Address"].ToString();
            //    btnUpdate.IsEnabled = true;
            //    btnDelete.IsEnabled = true;


            //}
            //else
            //{
            //  MessageBox.Show("student with id" + txtStudentCode + "  notfound");

            //}

        }
        public void Cleardata() //for clearing data in textbox after use
        {
            txtStudentCode.Text = "";
            txtName.Text = "";
            txtFullAddress.Text = "";
            txtDOB.Text = "";
            txtDeptCode.Text = "";

            btnUpdate.IsEnabled = true;
            btnDelete.IsEnabled = true;

        }


        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

            for (int i = 0; i < ds.Tables["Stud"].Rows.Count; i++)
            {
                if (ds.Tables["Stud"].Rows[i]["Stud_Code"].ToString() == txtStudentCode.Text)
                {
                    ds.Tables["Stud"].Rows[i]["Stud_Name"] = txtStudentCode.Text;
                    ds.Tables["Stud"].Rows[i]["Dept_Code"] = txtDeptCode.Text;
                    ds.Tables["Stud"].Rows[i]["Stud_Dob"] = Convert.ToDateTime(txtDOB.Text);
                    ds.Tables["Stud"].Rows[i]["Address"] = txtFullAddress.Text;
                }
            }
            int recordsaffected = da.Update(ds, "Stud");
            if (recordsaffected > 0)
            {
                MessageBox.Show("Student record updated succesfully");
                Cleardata();
            }
            else
                MessageBox.Show("Student record not updated");
            //for(int i=0;i<ds.Tables["Stud"].Rows.Count;i++) // to update the data
            //{
            //    if(ds.Tables["Stud"].Rows[i].ToString()==txtStudentCode.Text) //searching row by row for update
            //    {
            //        ds.Tables["Stud"].Rows[i]["Stud_Code"] = txtStudentCode.Text;
            //        ds.Tables["Stud"].Rows[i]["Stud_Name"] = txtName.Text;
            //        ds.Tables["Stud"].Rows[i]["Dept_Code"] =txtDeptCode .Text;
            //        ds.Tables["Stud"].Rows[i]["DOB"] =Convert.ToDateTime(txtDOB .Text);
            //        ds.Tables["Stud"].Rows[i]["Address"] =txtFullAddress.Text;
            //    }
            //}
            //int recordAffected = da.Update(ds, "Stud");     // updated rows can be affected in dataset
            //if (recordAffected>0)
            //{
            //    MessageBox.Show("student added succeessfully");
            //    Cleardata();
            //}

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            DataRow dr = ds.Tables["Stud"].Rows.Find(txtStudentCode.Text); //find row to delete detach obj
            //ds.Tables["Stud"].Rows.Remove (dr); // remove in local dir not in server
            dr.Delete(); //deleted
            int recordAffected = da.Update(ds, "Stud");
            if(recordAffected>0)
            {
                MessageBox.Show("student record deleted successfiully");
                Cleardata();
            }

        }

        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("no of students" + ds.Tables["Stud"].Rows.Count);

        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Cleardata();

        }
    }
}
