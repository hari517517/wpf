﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SMS.DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description : This class will be used for common database functionalities
    /// Date of Creation :
    /// </summary>
    public class DataConnection
    {
        //Function to create command object by assigning connection
        public static SqlCommand GenerateCommand()
        {
            SqlCommand cmd = null;

            try 
            {
                //Creating connection object
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
                //Creating Command object
                cmd = new SqlCommand();

                //Assigning common properties to command
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cmd;
        }
    }
}
