﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using TMS.Entity;
using TMS.Exception;
using System.Data.SqlClient;



    

namespace TMS.DAL
{
    public class TrainingOperation
    {
        public static int InsertStudent(Training train)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertStudent_172404`";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Stud_Code", train.StudCode);
                cmd.Parameters.AddWithValue("@Stud_Name", train.StudName);
                cmd.Parameters.AddWithValue("@Dept_Code", train.DeptCode);
                cmd.Parameters.AddWithValue("@DOB", train.DOB);
                cmd.Parameters.AddWithValue("@Address", train.Address);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static List<Training> RetrieveStudent()
        {
            List<Training> studList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayStudent";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    studList = new List<Training>();
                    while (dr.Read())
                    {
                        Training train = new Training();

                        train.StudCode = (int)dr["Student_Code"];
                        train.StudName = dr["Student_name"].ToString();
                        train.DeptCode = (int)dr["Dept_Code"];
                        train.DOB = Convert.ToDateTime(dr["Student_dob"]);
                        train.Address = dr["Student_Address"].ToString();

                        studList.Add(train);
                    }
                }
                else
                    throw new TrainingException("Record not available");
                cmd.Connection.Close();
            }
            catch (TrainingException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }

    }
}
