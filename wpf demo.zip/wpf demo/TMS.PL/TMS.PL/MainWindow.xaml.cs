﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMS.DAL;
using TMS.BAL;
using TMS.Entity;
using TMS.Exception;

namespace TMS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public void Show()
        {
            try
            {
                List<Training> studList =TrainingValidation.RetrieveStudent();

                if (studList == null || studList.Count <= 0)
                    throw new TrainingException("Records not available");
                else
                {
                    dgStudent.DataContext = studList;
                }
            }
            catch (TrainingException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Training train = new Training();

                train.StudCode = Convert.ToInt32(txtStudCode.Text);
                train.StudName = txtStudName.Text;
                train.DeptCode = Convert.ToInt32(txtDeptCode.Text);
                train.DOB = Convert.ToDateTime(txtStudDob.Text);
                train.Address = txtStudAddress.Text;

                int recordsAffected = TrainingValidation.InsertStudent(train);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");
                    
                }
                else
                    throw new TrainingException("Record not inserted");
            }
            catch (TrainingException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


    }
}
