﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TMS.Entity;
using TMS.Exception;
using TMS.DAL;

namespace TMS.BAL
{
    public class TrainingValidation
    {
        public static bool ValildateStudent(Training train)
        {
            bool studValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (train.StudCode <= 0)
                {
                    studValidated = false;
                    message.Append("Student code should be greater than 0\n");
                }

                if (train.StudName == String.Empty)
                {
                    studValidated = false;
                    message.Append("Student name should be provided\n");
                }
                else if (!Regex.IsMatch(train.StudName, "[A-Z][a-z]+"))
                {
                    studValidated = false;
                    message.Append("Student name should have alphabets only\n");
                }

                if (train.DOB == null)
                {
                    studValidated = false;
                    message.Append("Student Date of Birth should be provided\n");
                }

                if (studValidated == false)
                    throw new TrainingException (message.ToString());
            }
            catch (TrainingException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }

        public static int InsertStudent(Training train)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(train))
                {
                    recordsAffected = TrainingOperation.InsertStudent(train);
                }
                else
                    throw new TrainingException("Please provide valid Student Information");
            }
            catch (TrainingException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
