create table Training_1724041(Student_Code int,Student_Name varchar(50),Dept_Code int,Student_dob date,Student_Address varchar(50)
)






CREATE PROC usp_InsertStudent_172404
(
	@Stud_Code		INT,
	@Stud_Name		VARCHAR(30),
	@Dept_Code		INT,
	@DOB			DATE,
	@Address		VARCHAR(50)
)
AS
BEGIN
	INSERT INTO Training_1724041(Student_Code, Student_name, Dept_Code, Student_dob,Student_Address)
	VALUES(@Stud_Code, @Stud_Name, @Dept_Code, @DOB, @Address)
END

GO