﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.SqlTypes;
using System.Data;

namespace Form
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        public MainWindow()
        {


            InitializeComponent();
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        }
        public void ShowData()
        {


            cmd = new SqlCommand("SELECT * FROM Student_Master", con);

            con.Open();
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);

            con.Close();
            dgStudent.ItemsSource = dt.DefaultView;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();
            //dgStudent.DataContext = dt.DefaultView;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("INSERT INTO Student_Master(Stud_Code, Stud_Name,Dept_Code,Stud_Dob,Address)VALUES(@scode,@sname,@dcode,@dob,@address)", con);

            SqlParameter sid = new SqlParameter();
            sid.ParameterName = "@scode";
            sid.SqlDbType = SqlDbType.Decimal;
            sid.Direction = ParameterDirection.Input;
            sid.Value = txtStudentCode.Text;
            cmd.Parameters.Add(sid);
           


            SqlParameter name = new SqlParameter("@sname", txtName.Text);
            cmd.Parameters.Add(name);

            cmd.Parameters.Add(new SqlParameter("@dcode", txtDeptCode.Text));

            
                cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(txtDOB.Text));
           
            cmd.Parameters.AddWithValue("@address", txtFullAddress.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();

            con.Close();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Student Record added Successfully");
                ShowData();
               
            }
            else
                MessageBox.Show("Student record not added");
        }
        public void Cleardata()
        {
            txtStudentCode.Text = "";
            txtName.Text = "";
            txtFullAddress.Text = "";
            txtDOB.Text = "";
            txtDeptCode.Text = "";

            btnUpdate.IsEnabled = true;
            btnDelete.IsEnabled = true;

        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("SELECT * FROM Student_Master WHERE Stud_Code = @scode", con);
            cmd.Parameters.AddWithValue("@scode", txtStudentCode.Text);

            con.Open();
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                txtStudentCode.Text = dr["Stud_Code"].ToString();
                txtName.Text = dr["Stud_Name"].ToString();
                txtDeptCode.Text = dr["Dept_Code"].ToString();
                txtDOB.Text = dr["Stud_Dob"].ToString();
                txtFullAddress.Text = dr["Address"].ToString();

                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            else
            {
                MessageBox.Show("Student with id" + txtStudentCode.Text + "not found");
            }
            con.Close();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("UPDATE Student_Master SET Stud_dob = @dob,Address = @address WHERE Stud_Code = @scode", con);
            cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(txtDOB));
            cmd.Parameters.AddWithValue("@address", txtFullAddress.Text);
            cmd.Parameters.AddWithValue("@scode", txtStudentCode.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Student record updated successfully");
                ShowData();
                Cleardata();
            }
            else
            {
                MessageBox.Show("Student record not Updated");

            }

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("DELETE Student_Master WHERE  Stud_Code = @scode", con);
            cmd.Parameters.AddWithValue("@scode", txtStudentCode.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();


            if (recordsAffected > 0)
            {
                MessageBox.Show("Student record deleted successfully");
                ShowData();
                Cleardata();
            }
            else
            {
                MessageBox.Show("Student record not deleted");

            }
        }

        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("SELECT COUNT(*) FROM Student_Master ", con);
            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();

            MessageBox.Show("Number of Students are:" + count);

        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Cleardata();
        }
    }
}


