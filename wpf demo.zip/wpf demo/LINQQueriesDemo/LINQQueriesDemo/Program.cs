﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueriesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5, 5, 6, 7, 8, 9, 4, 21, 21, 24 };
            var result = from num in numbers
                         where num % 2 == 0
                         select num;


            Console.WriteLine("Even numbers");
            foreach (var item in result)
            {
                Console.WriteLine(item + "\t");
            }

            var rev = numbers.Reverse();
            Console.WriteLine("\n reverse numbers");
            foreach (var items in rev)
            {
                Console.WriteLine(items + "\t");
            }
            var group = numbers.ToLookup(n => n % 2);
            Console.WriteLine("\n\ngroup data:");
            foreach(IGrouping<int,int> item in group)
            {
                Console.WriteLine("key"+item.Key);
                foreach(var val in item)
                {
                    Console.WriteLine(val+"\t");
                }
            }
            Console.ReadKey();
        }
    }
}


    


          